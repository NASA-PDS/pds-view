For documentation regarding installation and operation of the Inspect Tool 
software, point your favorite browser to the ./doc/index.html file.
