/*
 * Copyright (c) 2002-2003 by OpenSymphony
 * All rights reserved.
 */
package com.opensymphony.xwork2.test;


/**
 * Marker interface to help test hierarchy traversal.
 *
 * @author Mark Woon
 */
public interface UserMarker {
}
