/*
 * Copyright (c) 2002-2006 by OpenSymphony
 * All rights reserved.
 */
package com.opensymphony.xwork2;

import java.util.HashMap;

import junit.framework.TestCase;


/**
 * Simple Test ActionContext's ThreadLocal
 * 
 * @author tm_jee
 * @version $Date: 2006-07-09 17:30:29 -0700 (Sun, 09 Jul 2006) $ $Id: ActionContextThreadLocalTest.java 1063 2006-07-10 00:30:29Z mrdon $
 */
public class ActionContextThreadLocalTest extends TestCase {

	
	public void testGetContext() throws Exception {
		assertNotNull(ActionContext.getContext());
	}
	
	public void testSetContext() throws Exception {
		ActionContext context = new ActionContext(new HashMap());
		ActionContext.setContext(context);
		assertEquals(context, ActionContext.getContext());
	}
}
