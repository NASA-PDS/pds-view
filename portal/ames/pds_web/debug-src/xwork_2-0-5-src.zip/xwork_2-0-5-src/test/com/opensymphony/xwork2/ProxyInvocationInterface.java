package com.opensymphony.xwork2;

/**
 * Need by the ProxyInvocationTest
 */
public interface ProxyInvocationInterface {
    public String show();
}
