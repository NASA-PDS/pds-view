This document is intended for use with a sample template extracted from 
http://pds.jpl.nasa.gov/ (the PDS "home page"). Instructions also exist in the 
source as comments ("<!-- -->"). Any problems or questions can be directed to 
Joshua Ganderson (joshua.a.ganderson@nasa.gov).

::INSTRUCTIONS::
1. Update title to reflect your node and page location (line 8)
2. Relocate linked resources listed below. Note that these differ somewhat from
   the resources hosted at pds.jpl.nasa.gov to simplify the template and make 
   it more flexible. Do not attempt to directly link to these resources at 
   pds.jpl.nasa.gov.
		a. template css (line 7)
		b. top logo (line 18)
		c. bottom logo (line 181)
		d. usa.gov logo (line 171)
		e. sub navigation arrow (line 77 though line is subject to change as 
		   you modify navigation)
		f. planets image [optional] (line 154)
3. Update each of the tab links and sub navigation to reflect your site 
   navigation. Note that the current section and subsection are shown to be 
   active by adding class="active" to the table cell (lines 60-65 & 76-77)
4. Update Privacy / Copyright link to the location of your policy (line 174)
5. Update the webmaster information in right side of footer (lines 184-186)
6. Update or remove site resource links (lines 27, 28)
7. If you have your own search, modify search box to leverage this. (line 34)
   Alternativey, you may use google search to search your hosted pages. Just 
   update the hidden input fields with names "domains" and "sitesearch" to your
   domain. (lines 36,37)
8. Add page specific content to body section beginning line 147. It is 
   recommended you save a copy of this template with the above changes prior to
   updating with page specific content.