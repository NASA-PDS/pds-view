For documentation regarding installation of the Report Service software, 
either point your favorite browser to the ./doc/index.html file or 
view the PDF file located at ./doc/transfer-logs-0.1.0-dev.pdf.
